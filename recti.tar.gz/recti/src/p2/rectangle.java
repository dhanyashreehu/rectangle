package p2;
import java.util.Scanner;
public class rectangle {
   int l, b, area;

  rectangle() {
      System.out.println("def cons");
      l = 0;
        b = 0;
        rarea(l,b);
    }
    rectangle(int len,int bre)
    {
    l=len;
    b=bre;
        System.out.println("param cons");
        rarea(l,b);
    }
    void rarea(int l, int b) {
        area = l * b;

  }

    void disp() {
        System.out.println("length and breadth are " + l+" " + b);
        System.out.println("area= " + area);
    }

        public static void main(String[] args)
        {
                     rectangle rect = new rectangle();
            rect.disp();
                    Scanner in=new Scanner(System.in);
            System.out.println("enter length of rectangle");
            int len=in.nextInt();
            System.out.println("enter breadth of rectangle");
            int bre=in.nextInt();
                    rectangle rect1=new rectangle(len,bre);
                    rect1.disp();
                      // System.out.println("l and b \n"+ rect.l +" and"+rect.b );
                      //System.out.println("area= "+rect1.area);

        }

}