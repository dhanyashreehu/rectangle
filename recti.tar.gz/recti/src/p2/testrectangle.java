package p2;
import java.util.Scanner;
public class testrectangle
{
     public static void main(String[] args)
    {
       // userrect rect1[] = new userrect[5];
        rectangle2 rect=new rectangle2();
        rect.disp();
        rectangle2 rect1[]=new rectangle2[5];
        for(int i=0;i<rect1.length;i++)
        {
         //   rec[i].disp();
           // rect1[i]=new userrect();
        Scanner in=new Scanner(System.in);
        System.out.println("enter length of rectangle");
        double len=in.nextDouble();
        System.out.println("enter breadth of rectangle");
        double bre=in.nextDouble();

                  //rect1[i]=new userrect(len,bre);
            if(len> 0 & bre>0) {
                rect1[i] = new rectangle2();
                rect1[i].setL(len);
                rect1[i].setB(bre);
                rect1[i].rarea(len, bre);
                rect1[i].disp();
            }
            else
                System.out.println("enter positive numbers only");
        }
    }

}
