package p2;
import java.util.Scanner;
public class rectangle2 {
  private double l, b, area;
rectangle2()
{
    l=0;
    b=0;
}
    public double getL() {
        return l;
    }

    public void setL(double l) {
        this.l = l;
    }

    public double getB() {
        return b;
    }

    public void setB(double b) {
        this.b = b;
    }

    void rarea(double l, double b) {
        area = l * b;

    }
    void disp() {
        System.out.println("length and breadth are " + l+" and" + b);
        double roundof=Math.round(area*100)/100;
                System.out.println("area= " +roundof);
      // System.out.printf("area= %.2D",area);
    }




   /* public static void main(String[] args)
    {
        rectangle2 rect = new rectangle2();
       rect.setL(10);
        rect.setB(10);
     //  rect.setb(4);
        System.out.println("l and b are\n"+ rect.getL() +" and"+rect.getB() );
        System.out.println("area of rect="+rect.getArea() );
           }
*/
}
