package books;
/*import java.util.Scanner;
//void Create_book();
//void Show_book();
public class Book {
    private String Book_title;
    private Double Book_price;

    public String getBook_title() {
        return Book_title;
    }

    public void setBook_title(String book_title) {
        Book_title = book_title;
    }

    public Double getBook_price() {
        return Book_price;
    }

    public void setBook_price(Double book_price) {
        Book_price = book_price;
    }
    public static void main(String[] args)
    {
        int n,i;
        System.out.println("enter the number of books to be created");
        Scanner scn=new Scanner();
        int n=scn.nextInt();
        Book b[]=new Book[n];
        for(i=0;i<n;i++)
        {
            b[i]=new Book();
            b[i].Create_book();
            b[i].Show_book();
        }
    }
}
    void Create_book()
    {
        System.out.println("enter the name of book");
        Scanner scn=new Scanner();
        Book_title=scn.nextLine();

    }
    /void Show_book()
    {
        System.out.println("");
    }


*/